The 6809 setting will display a menu. When you select the word or even the first letter of the 
language you want to run, the computer will look for the corresponding software in the ROOT 
of the floppy disk, or SD card. Therefore you need to copy all these files to the ROOT of the
diskette or SD card so that each language will work. If not, the development language will not
load and you will be sent back the menu.

6702 Failure and Replacement

The 6702 is required for the original versions of the SuperPET software but the programs 
have been cracked so they don't require the 6702. 
You can find them here: 
http://mikenaberezny.com/hardware/superpet/waterloo-languages/
