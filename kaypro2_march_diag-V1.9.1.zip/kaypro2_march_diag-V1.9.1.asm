; =============================================================================
;  KAYPRO II (1983, board 81-110)  -  MARCH C- DRAM DIAGNOSTIC BOOT ROM
;  Rudy's Retro Intel 2026                                         V1.9.1
;
;  Target : 2716 EPROM at U47 (2K), replaces the monitor ROM.
;  Tests  : all 64K of 4164 DRAM (U20-U27) with the March C- algorithm:
;             up(w0); up(r0,w1); up(r1,w0); down(r0,w1); down(r1,w0); up(r0)
;           Detects stuck-at, transition, address-decoder and coupling faults.
;
;  Stage 0: stack parked in video row 23, FDC quietened, then a stackless
;           pattern check of FF00h-FFFFh; the stack moves there if it passes
;           (video RAM is only 2 KB: columns 64-127 alias onto 64-79).
;  Video  : March C- over the 1920 visible video RAM cells (2114s U28-U31);
;           a fault is reported twice (top and bottom half) so one copy is
;           legible even with a dead nibble.
;  Stage 1: runs from ROM, tests 4000h-FEFFh (always DRAM in both banks).
;  Stage 2: copies a small test block to E000h (already verified), switches
;           the system port bank bit to all-RAM, tests 0000h-3FFFh, then
;           switches ROM back in.
;  Stage 3: moves the stack to BFFEh and March-tests FF00h-FFFFh as well.
;
;  Hardware facts (Micro Cornucopia "Kaypro II Theory of Operation", 1983,
;  cross-checked against the factory 81-149c monitor ROM):
;    System PIO port A data = 1Ch, control = 1Dh
;      bit 7 = bank select (1 = ROM+video at 0000h-3FFFh, 0 = all 64K DRAM)
;      bit 6 = disk drive motors (1 = off)   bits 2,3 = inputs
;    Video RAM = 3000h-3BFFh, 24 rows x 128 bytes (80 visible), bit 7 = blink
;    DRAM data bit N  ->  socket per SOCKTAB (measured on the board, not U20+N)
;
;  Assemble:  sjasmplus kaypro2_march_diag-V1.9.1.asm
; =============================================================================

        DEVICE  NONE
        OUTPUT  "kaypro2_march_diag-V1.9.1.bin"

; ---- hardware --------------------------------------------------------------
SYSPORT     EQU     1Ch             ; system PIO port A data
SYSCTRL     EQU     1Dh             ; system PIO port A control
FDCCMD      EQU     10h             ; WD1793 command (write) / status (read)
SYS_ROM     EQU     0C0h            ; bank=ROM/video, motors off, no drive sel
SYS_RAM     EQU     040h            ; bank=all DRAM,  motors off, no drive sel

VRAM        EQU     3000h
VSTRIDE     EQU     128
ROW0        EQU     VRAM+0*VSTRIDE
ROW1        EQU     VRAM+1*VSTRIDE
ROW2        EQU     VRAM+2*VSTRIDE
ROW4        EQU     VRAM+4*VSTRIDE
ROW5        EQU     VRAM+5*VSTRIDE
ROW6        EQU     VRAM+6*VSTRIDE
ROW7        EQU     VRAM+7*VSTRIDE
ROW8        EQU     VRAM+8*VSTRIDE
ROW9        EQU     VRAM+9*VSTRIDE
ROW10       EQU     VRAM+10*VSTRIDE
ROW11       EQU     VRAM+11*VSTRIDE
ROW23       EQU     VRAM+23*VSTRIDE
STATCOL     EQU     38              ; column for the region indicator on row 2

STACK       EQU     0000h           ; DRAM stack: FFFEh downward (page checked by stage 0)
VSTACK      EQU     3BC0h           ; early/emergency stack: row 23, columns 63 downward.
                                    ; Columns 0-63 are real, non-aliased cells (video RAM
                                    ; is 2 KB; columns 64-127 fold onto 64-79), so a stack
                                    ; here can be cleared safely and never hits other rows.
RAMCODE     EQU     0E000h          ; where the stage-2 block is copied

ROM_SIZE    EQU     2048

; =============================================================================
        ORG     0000h
RESET:  DI
        LD      SP,VSTACK           ; FIRST: a safe place for any early NMI push
        IM      1
        JP      MAIN

        DS      0066h-$, 0FFh
NMI:    RETN                        ; WD1793 INTRQ (power-on RESTORE) arrives here

; -----------------------------------------------------------------------------
MAIN:   LD      A,03h               ; PIO port A: interrupts disabled
        OUT     (SYSCTRL),A
        LD      A,SYS_ROM           ;   preload output latch (as 81-149c does)
        OUT     (SYSPORT),A
        LD      A,0CFh              ;   mode 3 (bit I/O)
        OUT     (SYSCTRL),A
        LD      A,0Ch               ;   direction mask: bits 2,3 input (same as 81-149c)
        OUT     (SYSCTRL),A

        LD      A,0D0h              ; WD1793 Force Interrupt: abort the power-on RESTORE
        OUT     (FDCCMD),A
        LD      BC,1000             ; ~10 ms: lets the FDC settle and gives the 4164s
DLY:    DEC     BC                  ;   plenty of RAS/refresh cycles before first use
        LD      A,B
        OR      C
        JR      NZ,DLY
        IN      A,(FDCCMD)          ; read status: clears INTRQ so no NMI comes later

        ; ---- stage 0: check of the stack page FF00h-FFFFh (no stack use) ----
        ; write L, verify, write ~L, verify: every bit sees a 0 and a 1.
        LD      HL,0FF00h
S0W:    LD      (HL),L
        INC     L
        JR      NZ,S0W
S0R1:   LD      A,(HL)
        CP      L
        JP      NZ,S0FAIL1
        LD      A,L
        CPL
        LD      (HL),A
        INC     L
        JR      NZ,S0R1
S0R2:   LD      A,L
        CPL
        LD      D,A
        LD      A,(HL)
        CP      D
        JP      NZ,S0FAIL2
        INC     L
        JR      NZ,S0R2

        LD      SP,STACK            ; stack page is good: use DRAM for the stack

        ; ---- video RAM: March C- over the 1920 visible cells ------------------
        CALL    VTEST
        JP      C,VFAULT

        LD      BC,0C00h            ; clear all of video RAM
        CALL    DRAWHDR
        LD      HL,S_VRES           ; "VIDEO RAM TEST: PASSED"
        LD      DE,ROW4
        CALL    PUTS
        LD      HL,S_PASSED
        CALL    PUTS

        ; ---- stage 1: 4000h-FEFFh from ROM ----------------------------------
        LD      HL,S_HI
        LD      DE,ROW2+STATCOL
        CALL    PUTS
        LD      HL,4000h
        LD      A,0BFh              ; 191 pages (stack page excluded)
        CALL    MARCH
        JP      C,FAULT

        ; ---- stage 2: 0000h-3FFFh with ROM banked out -----------------------
        LD      HL,S_LO
        LD      DE,ROW2+STATCOL
        CALL    PUTS
        LD      HL,RBLOCK
        LD      DE,RAMCODE
        LD      BC,RBLOCK_END-RBLOCK
        LDIR
        JP      RAMCODE

STAGE2_RET:
        JP      C,FAULT

        ; ---- stage 3: FF00h-FFFFh with the stack moved to verified DRAM -----
        LD      HL,S_TOP
        LD      DE,ROW2+STATCOL
        CALL    PUTS
        LD      SP,0C000h           ; stack at BFFEh downward
        LD      HL,0FF00h
        LD      A,01h               ; 1 page
        CALL    MARCH
        LD      SP,STACK            ; flags untouched
        JP      C,FAULT

        LD      HL,S_DONE
        LD      DE,ROW2
        CALL    PUTS
        LD      HL,S_MRES           ; "MAIN  RAM TEST: PASSED"
        LD      DE,ROW5
        CALL    PUTS
        LD      HL,S_PASSED
        CALL    PUTS
        LD      HL,S_PASS
        LD      DE,ROW7
        CALL    PUTS
        JR      $

; stack page is bad: keep the video-RAM stack (row 23) just to show the report
S0FAIL1:
        LD      D,L                 ; expected = address pattern
S0FAIL2:
        LD      E,A                 ; read
        PUSH    HL
        PUSH    DE
        LD      BC,0B80h            ; clear rows 0-22 only; row 23 holds the live stack
        CALL    DRAWHDR
        LD      HL,S_VRES           ; "VIDEO RAM TEST: SKIPPED" (needs a DRAM stack)
        LD      DE,ROW4
        CALL    PUTS
        LD      HL,S_SKIP
        CALL    PUTS
        POP     DE
        POP     HL
        JP      FAULT

; -----------------------------------------------------------------------------
;  DRAWHDR: clear BC bytes of video RAM and draw the three header lines
; -----------------------------------------------------------------------------
DRAWHDR:
        CALL    CLS
        LD      HL,S_TITLE
        LD      DE,ROW0
        CALL    PUTS
        INC     HL                  ; S_VER follows S_TITLE's terminator
        CALL    PUTS
        LD      HL,S_TEST
        LD      DE,ROW1
        CALL    PUTS
        LD      HL,S_STAT
        LD      DE,ROW2
        JP      PUTS

; CLS:  fill BC bytes of video RAM from VRAM with spaces
; FILL: fill BC bytes from HL with spaces.  A constant is written (not LDIR)
;       so a stuck video RAM bit cannot propagate across the screen.
CLS:    LD      HL,VRAM
FILL:   LD      (HL),' '
        INC     HL
        DEC     BC
        LD      A,B
        OR      C
        JR      NZ,FILL
        RET

; -----------------------------------------------------------------------------
;  VTEST: March C- over the visible video RAM (24 rows x 80 columns).
;    Columns 80-127 are skipped: they alias onto 64-79 (2 KB of 2114s).
;    Out: CF=0 pass;  CF=1 fail with HL = address, D = expected, E = read
;    Uses AF, BC, DE, HL.  Runs from ROM with the stack in DRAM.
; -----------------------------------------------------------------------------
        MACRO   VELEM dir, chk, exp, wr
        LD      D,exp
        LD      E,wr
        IF dir
        LD      HL,ROW23+79
        ELSE
        LD      HL,VRAM
        ENDIF
        LD      C,24                ; rows
1:      LD      B,80                ; columns
2:      IF chk
        LD      A,(HL)
        CP      D
        JP      NZ,VFAILX
        ENDIF
        LD      (HL),E
        IF dir
        DEC     HL
        ELSE
        INC     HL
        ENDIF
        DJNZ    2B
        LD      A,L                 ; hop over the 48 aliased bytes
        IF dir
        SUB     VSTRIDE-80
        LD      L,A
        JR      NC,3F
        DEC     H
        ELSE
        ADD     A,VSTRIDE-80
        LD      L,A
        JR      NC,3F
        INC     H
        ENDIF
3:      DEC     C
        JR      NZ,1B
        ENDM

VTEST:  VELEM   0, 0, 000h, 000h    ; M0: up   (w0)
        VELEM   0, 1, 000h, 0FFh    ; M1: up   (r0,w1)
        VELEM   0, 1, 0FFh, 000h    ; M2: up   (r1,w0)
        VELEM   1, 1, 000h, 0FFh    ; M3: down (r0,w1)
        VELEM   1, 1, 0FFh, 000h    ; M4: down (r1,w0)
        VELEM   0, 1, 000h, 000h    ; M5: up   (r0)
        OR      A
        RET
VFAILX: LD      E,A
        SCF
        RET

; -----------------------------------------------------------------------------
;  VFAULT: HL = address, D = expected, E = read.
;    The report is drawn twice (rows 0-6 and 13-19) because a dead 2114
;    garbles one nibble of one half of the screen: one copy stays legible.
; -----------------------------------------------------------------------------
VF_ADDR     EQU     0FF00h          ; DRAM scratch (page verified by stage 0,
VF_READ     EQU     0FF02h          ;  far below the stack at FFFEh)
VF_EXP      EQU     0FF03h
VF_ROW      EQU     0FF04h
VF_PAIR     EQU     0FF05h          ; 0 = fault in 2114 pair 1, 2 = pair 2

VFAULT: LD      (VF_ADDR),HL
        LD      (VF_READ),DE        ; E -> VF_READ, D -> VF_EXP
        LD      A,H                 ; row = ((H-30h)*2) | bit7(L)
        SUB     HIGH VRAM
        ADD     A,A
        BIT     7,L
        JR      Z,VFR0
        INC     A
VFR0:   LD      (VF_ROW),A
        ; pair 2 = column >= 64 OR row >= 16 (measured: U16 selects the
        ; second 1K of 2114s that way)
        LD      C,2
        LD      A,L
        AND     7Fh
        CP      64
        JR      NC,VFP
        LD      A,(VF_ROW)
        CP      16
        JR      NC,VFP
        LD      C,0
VFP:    LD      A,C
        LD      (VF_PAIR),A
        LD      BC,0C00h
        CALL    CLS
        ; draw the single report inside the GOOD pair: rows 0-6 if the fault
        ; is in pair 2, rows 16-22 if it is in pair 1
        LD      IX,ROW0
        LD      A,(VF_PAIR)
        OR      A
        JR      NZ,VFDRAW
        LD      IX,VRAM+16*VSTRIDE
VFDRAW: CALL    VREP
        JR      $

VREP:   PUSH    IX
        POP     DE
        LD      HL,S_TITLE          ; 58 columns: stays inside columns 0-63
        CALL    PUTS
        CALL    NEXTROW

        PUSH    IX
        POP     DE
        LD      HL,S_VF1            ; "RESULT: VIDEO RAM FAULT (2114 U28-U31) AT 0x"
        CALL    PUTS
        LD      HL,(VF_ADDR)
        CALL    PUTHEX16
        CALL    NEXTROW

        PUSH    IX
        POP     DE
        LD      HL,S_VROW           ; "  ROW: "
        CALL    PUTS
        LD      A,(VF_ROW)
        CALL    PUTDEC2
        LD      HL,S_VCOL           ; "  COL: "
        CALL    PUTS
        LD      A,(VF_ADDR)
        AND     7Fh
        CALL    PUTDEC2
        CALL    NEXTROW

        LD      A,(VF_EXP)          ; C = differing bits
        LD      HL,VF_READ
        XOR     (HL)
        LD      C,A
        PUSH    IX
        POP     DE
        LD      HL,S_VBITS          ; "  FAIL BITS: "
        CALL    PUTS
        CALL    LISTBITS
        CALL    NEXTROW

        PUSH    IX
        POP     DE
        LD      HL,S_EXP
        CALL    PUTS
        LD      A,(VF_EXP)
        CALL    PUTBIN8
        LD      HL,S_READ
        CALL    PUTS
        LD      A,(VF_READ)
        CALL    PUTBIN8
        CALL    NEXTROW

        PUSH    IX
        POP     DE
        LD      HL,S_VNIB           ; "  NIBBLE: "
        CALL    PUTS
        LD      B,0                 ; B = nibble index (0 low, 1 high)
        LD      A,C
        AND     0Fh
        JR      Z,VNHIGH
        LD      A,C
        AND     0F0h
        LD      HL,S_LOWN
        JR      Z,VNPUT
        LD      HL,S_BOTHN
        JR      VNPUT
VNHIGH: INC     B
        LD      HL,S_HIGHN
VNPUT:  CALL    PUTS
        CALL    NEXTROW

        PUSH    IX
        POP     DE
        LD      HL,S_VSUS           ; "==> SUSPECT 2114 AT SOCKET "
        CALL    PUTS
        ; index = nibble + pair (0 or 2), 4 bytes per entry
        LD      A,(VF_PAIR)
        ADD     A,B
        ADD     A,A
        ADD     A,A
        LD      HL,VSOCKTAB
        ADD     A,L
        LD      L,A
        CALL    PUTS
        LD      HL,S_ARROW
        CALL    PUTS
        CALL    NEXTROW
        RET

NEXTROW:
        LD      DE,VSTRIDE
        ADD     IX,DE
        RET

; PUTDEC2: A (0-99) as two decimal digits at DE.  Clobbers C and AF'.
PUTDEC2:
        LD      C,'0'
PDEC1:  SUB     10
        JR      C,PDEC2
        INC     C
        JR      PDEC1
PDEC2:  ADD     A,'0'+10            ; units digit as ASCII
        EX      AF,AF'
        LD      A,C                 ; tens digit
        LD      (DE),A
        INC     DE
        EX      AF,AF'
        LD      (DE),A
        INC     DE
        RET

; -----------------------------------------------------------------------------
;  FAULT: HL = address, D = expected, E = read
; -----------------------------------------------------------------------------
FAULT:  PUSH    HL
        POP     IX                  ; IX  = fault address
        PUSH    DE
        POP     IY                  ; IYH = expected, IYL = read

        LD      HL,S_STOP
        LD      DE,ROW2
        CALL    PUTS
        LD      HL,S_MRES           ; "MAIN  RAM TEST: FAILED"
        LD      DE,ROW5
        CALL    PUTS
        LD      HL,S_FAILED
        CALL    PUTS

        LD      HL,S_FAULT
        LD      DE,ROW7
        CALL    PUTS
        PUSH    IX
        POP     HL
        CALL    PUTHEX16
        LD      A,'!'
        LD      (DE),A

        LD      HL,S_BANK
        LD      DE,ROW8
        CALL    PUTS

        ; C = mask of differing bits, B = 0 if exactly one bit, else non-zero
        PUSH    IY
        POP     BC
        LD      A,B
        XOR     C
        LD      C,A
        DEC     A
        AND     C
        LD      B,A

        LD      HL,S_BIT            ; "  FAIL BIT" / "  FAIL BITS"
        LD      DE,ROW9
        CALL    PUTS
        CALL    PLURAL
        LD      HL,S_BIT2           ; ": BIT" / ": BITS"
        CALL    PUTS
        CALL    PLURAL
        LD      A,' '
        LD      (DE),A
        INC     DE
        CALL    LISTBITS
        LD      HL,S_DATA
        CALL    PUTS
        CALL    LISTBITS
        LD      A,')'
        LD      (DE),A

        LD      HL,S_EXP
        LD      DE,ROW10
        CALL    PUTS
        PUSH    IY
        POP     HL
        LD      A,H
        CALL    PUTBIN8
        LD      HL,S_READ
        CALL    PUTS
        PUSH    IY
        POP     HL
        LD      A,L
        CALL    PUTBIN8

        ; one REPLACE line per failing bit, starting at ROW11
        LD      IX,ROW11            ; IX = current row
        LD      B,0                 ; B = bit number
FREPL:  RRC     C
        JR      NC,FREPL1
        PUSH    IX
        POP     DE
        LD      HL,S_REPL           ; "==> REPLACE DRAM IC AT SOCKET "
        CALL    PUTS
        LD      HL,SOCKTAB          ; HL = SOCKTAB + 4*bit
        LD      A,B
        ADD     A,A
        ADD     A,A
        ADD     A,L
        LD      L,A
        CALL    PUTS
        LD      HL,S_REPL1          ; " (DATA BIT "
        CALL    PUTS
        LD      A,B
        ADD     A,'0'
        LD      (DE),A
        INC     DE
        LD      HL,S_REPL2          ; ") <=="
        CALL    PUTS
        LD      DE,VSTRIDE
        ADD     IX,DE
FREPL1: INC     B
        LD      A,B
        CP      8
        JR      NZ,FREPL

        LD      HL,ROW11            ; blink only the "==>" / "<==" arrows (bit 7)
        LD      BC,8*VSTRIDE        ; rows 11..18
FBLINK: LD      A,(HL)
        CP      '='
        JR      Z,FBLNK2
        CP      '<'
        JR      Z,FBLNK2
        CP      '>'
        JR      NZ,FBLNK1
FBLNK2: SET     7,(HL)
FBLNK1: INC     HL
        DEC     BC
        LD      A,B
        OR      C
        JR      NZ,FBLINK

        ; Report complete and nothing live on the stack any more, so the row
        ; that hosted the emergency stack (fallback path) can be wiped too.
        ; (inline, no CALL: in the fallback path the stack lives in this row)
        LD      HL,ROW23
        LD      B,80
FROW23: LD      (HL),' '
        INC     HL
        DJNZ    FROW23
        JR      $

; -----------------------------------------------------------------------------
;  Screen helpers.  None of them touch B or C.
; -----------------------------------------------------------------------------
; PLURAL: write 'S' at DE if B is non-zero
PLURAL: LD      A,B
        OR      A
        RET     Z
        LD      A,'S'
        LD      (DE),A
        INC     DE
        RET

; LISTBITS: for every set bit in C write "n " at DE (bit 0 first); the
;           trailing space is dropped.  C is never 0 here.
LISTBITS:
        PUSH    BC
        LD      B,0
LBIT1:  RRC     C
        JR      NC,LBIT2
        LD      A,B
        ADD     A,'0'
        LD      (DE),A
        INC     DE
        LD      A,' '
        LD      (DE),A
        INC     DE
LBIT2:  INC     B
        LD      A,B
        CP      8
        JR      NZ,LBIT1
        DEC     DE
        POP     BC
        RET

; PUTS: copy 0-terminated string at HL to screen at DE; DE ends past last char
PUTS:   LD      A,(HL)
        OR      A
        RET     Z
        LD      (DE),A
        INC     HL
        INC     DE
        JR      PUTS

; PUTHEX16: HL as 4 uppercase hex digits at DE
PUTHEX16:
        LD      A,H
        CALL    PUTHEX8
        LD      A,L
PUTHEX8:
        PUSH    AF
        RRCA
        RRCA
        RRCA
        RRCA
        CALL    PUTNIB
        POP     AF
PUTNIB: AND     0Fh
        ADD     A,90h
        DAA
        ADC     A,40h
        DAA
        LD      (DE),A
        INC     DE
        RET

; PUTBIN8: A as 8 binary digits (MSB first) at DE
PUTBIN8:
        PUSH    BC
        LD      C,8
PBIN1:  RLCA
        PUSH    AF
        LD      A,'0'
        ADC     A,0
        LD      (DE),A
        INC     DE
        POP     AF
        DEC     C
        JR      NZ,PBIN1
        POP     BC
        RET

; -----------------------------------------------------------------------------
;  Stage-2 block.  Copied to RAMCODE and executed there, because the ROM
;  disappears from 0000h-3FFFh while that region is under test.
; -----------------------------------------------------------------------------
RBLOCK:
        DISP    RAMCODE
        LD      A,SYS_RAM           ; (stack already at FFFEh downward in DRAM)
        OUT     (SYSPORT),A         ; ROM out, DRAM in
        LD      HL,0000h
        LD      A,40h               ; 64 pages
        CALL    RAMCODE+(MARCH-RBLOCK)
        LD      A,SYS_ROM
        OUT     (SYSPORT),A         ; ROM back in (flags untouched)
        JP      STAGE2_RET
        ENT

; -----------------------------------------------------------------------------
;  MARCH: March C- over A pages (256 bytes each) starting at HL (page aligned)
;    Out: CF=0 pass
;         CF=1 fail, HL = address, D = expected, E = value read
;    Position independent (relative jumps only) so it runs from ROM or RAM.
;    Uses AF, AF', BC, DE, HL, IX
; -----------------------------------------------------------------------------
        MACRO   MELEM dir, exp, wr
        PUSH    IX
        POP     HL
        EX      AF,AF'
        LD      C,A                 ; C = page count
        EX      AF,AF'
        IF dir
        LD      A,H                 ; descending: start at last byte
        ADD     A,C
        LD      H,A
        DEC     HL
        ENDIF
        LD      D,exp
        LD      E,wr
        LD      B,0
1:      LD      A,(HL)
        CP      D
        JR      NZ,9F
        LD      (HL),E
        IF dir
        DEC     HL
        ELSE
        INC     HL
        ENDIF
        DJNZ    1B
        DEC     C
        JR      NZ,1B
        ENDM

MARCH:  PUSH    HL
        POP     IX                  ; IX = start
        EX      AF,AF'              ; A' = page count

        ; M0: up (w0)
        PUSH    IX
        POP     HL
        EX      AF,AF'
        LD      C,A
        EX      AF,AF'
        LD      B,0
        XOR     A
1:      LD      (HL),A
        INC     HL
        DJNZ    1B
        DEC     C
        JR      NZ,1B

        MELEM   0, 000h, 0FFh       ; M1: up   (r0,w1)
        MELEM   0, 0FFh, 000h       ; M2: up   (r1,w0)
        MELEM   1, 000h, 0FFh       ; M3: down (r0,w1)
        MELEM   1, 0FFh, 000h       ; M4: down (r1,w0)
        MELEM   0, 000h, 000h       ; M5: up   (r0)

        OR      A                   ; CF = 0 : pass
        RET
9:      LD      E,A                 ; fail: E = read, D = expected, HL = addr
        SCF
        RET
RBLOCK_END:

; -----------------------------------------------------------------------------
;  Strings
; -----------------------------------------------------------------------------
S_TITLE: DB "=== KAYPRO MARCH C- DRAM DIAG - RUDYS RETRO INTEL 2026 ===",0
S_VER:   DB "  V1.9.1",0           ; must directly follow S_TITLE
S_TEST:  DB "TESTING 2K VIDEO RAM (U28-U31) + 64K DRAM (U20-U27)",0
S_STAT:  DB "STATUS: RUNNING MARCH C- ALGORITHM...",0
S_HI:    DB "[4000-FEFF]",0
S_LO:    DB "[0000-3FFF]",0
S_TOP:   DB "[FF00-FFFF]",0
; Both status strings span columns 0-48 (or 0-36 + the region tag) so they
; fully overwrite "STATUS: RUNNING MARCH C- ALGORITHM... [xxxx-xxxx]".
S_DONE:  DB "STATUS: MARCH C- COMPLETE, ALL REGIONS TESTED OK ",0
S_STOP:  DB "STATUS: STOPPED AT FIRST FAULT, RANGE",0
S_PASS:  DB "RESULT: ALL TESTS PASSED (0 ERRORS)",0
S_VRES:  DB "VIDEO RAM TEST: ",0
S_MRES:  DB "MAIN  RAM TEST: ",0
S_PASSED: DB "PASSED",0
S_FAILED: DB "FAILED",0
S_SKIP:   DB "SKIPPED",0
S_FAULT: DB "RESULT: RAM FAULT AT ADDRESS 0x",0
S_BANK:  DB "  BANK    : BANK 0 (U20-U27)",0
S_BIT:   DB "  FAIL BIT",0
S_BIT2:  DB ": BIT",0
S_DATA:  DB " (DATA ",0
S_EXP:   DB "  EXPECTED: ",0
S_READ:  DB " | READ: ",0
S_REPL:  DB "==> REPLACE DRAM IC AT SOCKET ",0
S_REPL1: DB " (DATA BIT ",0
S_REPL2: DB ") <==",0
S_ARROW: DB " <==",0
S_VF1:   DB "RESULT: VIDEO RAM FAULT AT 0x",0
S_VROW:  DB "  ROW: ",0
S_VCOL:  DB "  COL: ",0
S_VBITS: DB "  FAIL BITS: ",0
S_VNIB:  DB "  NIBBLE: ",0
S_LOWN:  DB "LOW (D0-D3)",0
S_HIGHN: DB "HIGH (D4-D7)",0
S_BOTHN: DB "BOTH (CHECK U16-U19)",0
S_VSUS:  DB "==> SUSPECT 2114 AT SOCKET ",0

; Video RAM nibble/pair -> 2114 socket.  4 bytes per entry (3 chars + 0).
;   pair 1 = rows 0-15, columns 0-63            (1024 cells)
;   pair 2 = rows 16-23, plus columns 64-79 of every row (896 cells)
; Survey on the real board (Nov 2026): U30 = pair 1 low, U29 = pair 1 high,
; U31 = pair 2 low, U28 = pair 2 high.
        ALIGN   16, 0FFh
VSOCKTAB: DB "U30",0                ; 0: pair 1, low nibble  (D0-D3)
          DB "U29",0                ; 1: pair 1, high nibble (D4-D7)
          DB "U31",0                ; 2: pair 2, low nibble  (D0-D3)
          DB "U28",0                ; 3: pair 2, high nibble (D4-D7)

; Data bus bit -> DRAM socket.  4 bytes per entry (3 chars + 0), bit 0 first.
; ALIGN 32 keeps the table inside one 256-byte page so the 8-bit add is safe.
; Measured on the real 81-110 board by pulling one 4164 at a time (Nov 2026).
        ALIGN   32, 0FFh
SOCKTAB: DB "U27",0                 ; bit 0  (D0)
         DB "U26",0                 ; bit 1  (D1)
         DB "U25",0                 ; bit 2  (D2)
         DB "U24",0                 ; bit 3  (D3)
         DB "U23",0                 ; bit 4  (D4)
         DB "U22",0                 ; bit 5  (D5)
         DB "U20",0                 ; bit 6  (D6)
         DB "U21",0                 ; bit 7  (D7)

CODE_END:
        DS      ROM_SIZE-$, 0FFh    ; pad erased-EPROM style to 2K
