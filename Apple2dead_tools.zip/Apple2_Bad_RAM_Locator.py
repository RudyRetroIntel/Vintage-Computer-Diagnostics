import tkinter as tk
from tkinter import ttk, messagebox

# --- Configuration & Global State ---
COLOR_FAULT_BG = "#ff4d4d" # Bright modern red for highlights
COLOR_FAULT_FG = "white"
# Attempt to get system default colors for reset
try:
    _dummy = tk.Tk()
    COLOR_DEFAULT_BG = _dummy.cget("bg")
    _dummy.destroy()
except:
    COLOR_DEFAULT_BG = "#f0f0f0"
COLOR_DEFAULT_FG = "black"

# Dictionary to hold references to the visual grid Label widgets
visual_chip_widgets = {}
VISUAL_TAB_INDEX = 3 # Index of the new Visual tab in the notebook

# --- Helper Function: Update Visual Grid ---
def update_visual_highlights(faulty_chips_list):
    """Resets the visual grid and highlights provided chip IDs."""
    # 1. Reset all chips to default state
    for chip_id, widget in visual_chip_widgets.items():
        widget.config(bg=COLOR_DEFAULT_BG, fg=COLOR_DEFAULT_FG, relief="groove")
    
    # 2. Highlight faulty chips
    actual_faults_found = False
    for chip_id in faulty_chips_list:
        if chip_id in visual_chip_widgets:
            visual_chip_widgets[chip_id].config(
                bg=COLOR_FAULT_BG, 
                fg=COLOR_FAULT_FG, 
                relief="sunken"
            )
            actual_faults_found = True
            
    # 3. Switch to Visual Tab automatically so user sees it
    if actual_faults_found:
        notebook.select(VISUAL_TAB_INDEX)

# --- Diagnostic Logic Functions (Modified to trigger visual update) ---

def locate_hex_fault():
    hex_str = mask_entry.get().strip().replace("0x", "").upper()
    page_selection = page_var.get()
    
    if not hex_str:
        messagebox.showerror("Input Error", "Please enter a Hex Error Mask.")
        return
        
    try:
        mask_val = int(hex_str, 16)
    except ValueError:
        messagebox.showerror("Input Error", "Invalid Hex value. Example entries: 10, 08, 40.")
        return
        
    if mask_val <= 0 or mask_val > 0xFF:
        messagebox.showerror("Input Error", "Hex Mask must be between 01 and FF.")
        return

    # Identify active bits (D0-D7)
    active_bits = [bit for bit in range(8) if (mask_val & (1 << bit))]
    
    # Map page range to row(s)
    row_map = {
        "Pages 0–3 (Bank 0)": ["C"],
        "Pages 4–7 (Bank 1)": ["D"],
        "Pages 8–B (Bank 2)": ["E"],
        "All Pages (0–B) / Global": ["C", "D", "E"]
    }
    rows = row_map[page_selection]
    
    results = []
    faulty_chips = []
    
    # Calculate Chip IDs
    for bit in active_bits:
        col = bit + 3 # Apply physical PCB offset
        for row in rows:
            chip_id = f"{row}{col}"
            faulty_chips.append(chip_id)
            results.append(f"• Bit D{bit} -> Column {col} (Row {row}) -> Socket {chip_id}")
            
    # Output formatting for text box
    summary = f"Identified Socket(s): {', '.join(faulty_chips)}\n\nDetails:\n" + "\n".join(results)
    if page_selection == "All Pages (0–B) / Global":
        summary += "\n\n[!] Note: Errors across all pages indicate a shorted trace or chip pulling down the shared line for that column."
        
    # Update Text Display
    hex_output_text.config(state="normal")
    hex_output_text.delete("1.0", tk.END)
    hex_output_text.insert(tk.END, summary)
    hex_output_text.config(state="disabled")
    
    # --- TRIGGER VISUAL UPDATE ---
    update_visual_highlights(faulty_chips)

def locate_beep_fault():
    try:
        # Extract just the number from "X Beep(s)" selection
        beep_count = int(beep_var.get().split()[0])
    except ValueError:
        messagebox.showerror("Input Error", "Please select a valid beep count (1-8).")
        return

    bit = beep_count - 1
    col = beep_count + 2 # Offset maps Beep 1 (D0) to Col 3
    socket_id = f"C{col}"

    summary = (
        f"Identified Socket: {socket_id}\n\n"
        f"Details:\n"
        f"• Bank: Bank 0 (Row C, Pages 0–3)\n"
        f"• Beep Count: {beep_count}\n"
        f"• Data Bit: D{bit}\n"
        f"• PCB Column: {col} (Bit {bit} + 3 offset)\n"
        f"• Target Socket: Row C + Column {col} = {socket_id}\n\n"
        f"Note: Screen garbage occurs because Bank 0 holds system zero-page, "
        f"stack, and screen memory ($0400–$07FF). When Bank 0 fails, video display "
        f"cannot render text properly, defaulting to audio diagnostics."
    )

    # Update Text Display
    beep_output_text.config(state="normal")
    beep_output_text.delete("1.0", tk.END)
    beep_output_text.insert(tk.END, summary)
    beep_output_text.config(state="disabled")
    
    # --- TRIGGER VISUAL UPDATE ---
    update_visual_highlights([socket_id]) # Pass as a list


# --- Main Window Setup ---
root = tk.Tk()
root.title("Apple II Dead Test RAM Locator (Visual)")
# Adjusted size slightly for the visual grid tab padding
root.geometry("580x560") 
root.resizable(False, False)

# Try setting Windows 11 look/feel if available
try:
    from ctypes import windll
    windll.shcore.SetProcessDpiAwareness(1) # Fix blurry text on high DPI
except:
    pass # Fallback for non-windows or old systems

style = ttk.Style()
# Try a more modern theme if on Windows
if "vista" in style.theme_names():
    style.theme_use("vista")

notebook = ttk.Notebook(root)
notebook.pack(fill="both", expand=True, padx=2, pady=2)

# =============================================================================
# ----------------- TAB 1: HEX ERROR MASK -----------------
# =============================================================================
tab1 = ttk.Frame(notebook, padding="20")
notebook.add(tab1, text="Screen Error (Hex Mask)")

ttk.Label(tab1, text="Step 1: Select Page Range / Bank:", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w", pady=(0, 5))
page_var = tk.StringVar(value="Pages 4–7 (Bank 1)")
page_dropdown = ttk.Combobox(
    tab1, 
    textvariable=page_var, 
    values=["Pages 0–3 (Bank 0)", "Pages 4–7 (Bank 1)", "Pages 8–B (Bank 2)", "All Pages (0–B) / Global"], 
    state="readonly", 
    width=40,
    font=("Segoe UI", 9)
)
page_dropdown.grid(row=1, column=0, sticky="w", pady=(0, 15))

ttk.Label(tab1, text="Step 2: Enter Hex Error Mask (e.g., 10, 08, 40):", font=("Segoe UI", 10, "bold")).grid(row=2, column=0, sticky="w", pady=(0, 5))
mask_entry = ttk.Entry(tab1, width=42, font=("Segoe UI", 9))
mask_entry.grid(row=3, column=0, sticky="w", pady=(0, 15))
mask_entry.insert(0, "10")

calc_hex_btn = ttk.Button(tab1, text="Identify Bad Chip ->", command=locate_hex_fault)
calc_hex_btn.grid(row=4, column=0, sticky="w", pady=(0, 15))

ttk.Label(tab1, text="Text Diagnostic Result:", font=("Segoe UI", 10, "bold")).grid(row=5, column=0, sticky="w", pady=(0, 5))
# Text Area for detailed results
hex_output_text = tk.Text(tab1, width=68, height=12, font=("Consolas", 9), state="disabled", bg="#f8f9fa", wrap="word", relief="solid", borderwidth=1)
hex_output_text.grid(row=6, column=0, sticky="w")

# =============================================================================
# ----------------- TAB 2: BEEP CODES & GARBAGE SCREEN -----------------
# =============================================================================
tab2 = ttk.Frame(notebook, padding="20")
notebook.add(tab2, text="Screen Garbage / Audio Beeps")

ttk.Label(tab2, text="Step 1: Select Number of Beeps Heard:", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w", pady=(0, 5))
beep_var = tk.StringVar(value="1 Beep")
beep_dropdown = ttk.Combobox(
    tab2,
    textvariable=beep_var,
    values=[f"{i} Beep{'s' if i > 1 else ''}" for i in range(1, 9)],
    state="readonly",
    width=40,
    font=("Segoe UI", 9)
)
beep_dropdown.grid(row=1, column=0, sticky="w", pady=(0, 15))

calc_beep_btn = ttk.Button(tab2, text="Identify Row C Chip ->", command=locate_beep_fault)
calc_beep_btn.grid(row=2, column=0, sticky="w", pady=(0, 15))

ttk.Label(tab2, text="Text Diagnostic Result:", font=("Segoe UI", 10, "bold")).grid(row=3, column=0, sticky="w", pady=(0, 5))
# Text Area for detailed results
beep_output_text = tk.Text(tab2, width=68, height=11, font=("Consolas", 9), state="disabled", bg="#f8f9fa", wrap="word", relief="solid", borderwidth=1)
beep_output_text.grid(row=4, column=0, sticky="w", pady=(0, 15))

# Audio Quick Reference Table inside Tab 2
beep_ref = (
    "BEEP CODE QUICK REFERENCE (Affects Bank 0 / Row C Only):\n"
    "----------------------------------------------------------\n"
    "1 Beep  = Bit D0 -> C3 | 5 Beeps = Bit D4 -> C7\n"
    "2 Beeps = Bit D1 -> C4 | 6 Beeps = Bit D5 -> C8\n"
    "3 Beeps = Bit D2 -> C5 | 7 Beeps = Bit D6 -> C9\n"
    "4 Beeps = Bit D3 -> C6 | 8 Beeps = Bit D7 -> C10"
)
beep_ref_text = tk.Text(tab2, width=68, height=6, font=("Consolas", 8), bg="#e8f0fe", relief="flat")
beep_ref_text.insert(tk.END, beep_ref)
beep_ref_text.config(state="disabled")
beep_ref_text.grid(row=5, column=0, sticky="w")

# =============================================================================
# ----------------- TAB 3: TEXT PCB MATRIX & PINOUT (Existing) -----------------
# =============================================================================
tab3 = ttk.Frame(notebook, padding="20")
notebook.add(tab3, text="Text Map & Pinout")

pcb_info = (
    "APPLE II / II+ RAM MATRIX LAYOUT (3x8 GRID)\n"
    "==========================================================\n"
    "View: Top-down, looking at motherboard component side.\n"
    "Data Bit:    D0   D1   D2   D3   D4   D5   D6   D7\n"
    "Column:       3    4    5    6    7    8    9   10\n"
    "----------------------------------------------------------\n"
    "Row E (8-B): [E3] [E4] [E5] [E6] [E7] [E8] [E9] [E10] (Bank 2: 32-48K)\n"
    "Row D (4-7): [D3] [D4] [D5] [D6] [D7] [D8] [D9] [D10] (Bank 1: 16-32K)\n"
    "Row C (0-3): [C3] [C4] [C5] [C6] [C7] [C8] [C9] [C10] (Bank 0: 0-16K)\n"
    "==========================================================\n\n"
    "4116 DRAM POWER RAIL PINOUTS (Verify these before pulling ICs):\n"
    "----------------------------------------------------------\n"
    "• Pin 1:  -5V DC  <--- CRITICAL: Missing -5V destroys 4116 chips instantly!\n"
    "• Pin 8: +12V DC\n"
    "• Pin 9:  +5V DC\n"
    "• Pin 16: Ground (GND)\n\n"
    "Tip: Columns 1 and 2 on the PCB grid are occupied by logic chips, not RAM."
)

map_text = tk.Text(tab3, width=68, height=22, font=("Consolas", 9), bg="#f8f9fa", wrap="word", relief="solid", borderwidth=1)
map_text.insert(tk.END, pcb_info)
map_text.config(state="disabled")
map_text.pack(fill="both", expand=True)

# =============================================================================
# ----------------- NEW TAB 4: VISUAL PCB HIGHLIGHT -----------------
# =============================================================================
tab4 = ttk.Frame(notebook, padding="25")
notebook.add(tab4, text="VISUAL PCB LOCATOR")

ttk.Label(tab4, text="Graphical Motherboard RAM Map", font=("Segoe UI", 12, "bold")).pack(pady=(0, 20))

# Container Frame for the grid to centralize it
grid_frame = ttk.Frame(tab4)
grid_frame.pack()

# --- HEADER ROW (Data Bits/Columns) ---
# Empty corner label for grid alignment
ttk.Label(grid_frame, text="Bit:", font=("Segoe UI", 9, "bold")).grid(row=0, column=0, padx=5, pady=5)

data_bits = ["D0", "D1", "D2", "D3", "D4", "D5", "D6", "D7"]
for col_idx, bit_name in enumerate(data_bits):
    # Display Data Bit Name
    ttk.Label(grid_frame, text=bit_name, font=("Segoe UI", 9)).grid(row=0, column=col_idx+1, padx=2, pady=2)
    # Display physical PCB Column number below it
    pcb_col_num = col_idx + 3
    ttk.Label(grid_frame, text=f"(Col {pcb_col_num})", font=("Segoe UI", 8, "italic"), foreground="gray").grid(row=1, column=col_idx+1, padx=2, pady=(0,10))

# --- GENERATE SOCKET GRID (Rows E, D, C) ---
rows_to_generate = [
    ("E", "Bank 2\n(8-B)"), 
    ("D", "Bank 1\n(4-7)"), 
    ("C", "Bank 0\n(0-3)")
]

for row_idx_in_grid, (row_letter, bank_desc) in enumerate(rows_to_generate):
    # Row Label (e.g., "Row E")
    ttk.Label(grid_frame, text=f"Row {row_letter}:", font=("Segoe UI", 9, "bold")).grid(row=row_idx_in_grid+2, column=0, padx=(0, 15), pady=10, sticky="e")
    
    # Generate 8 Sockets per Row
    for bit_idx in range(8):
        pcb_col = bit_idx + 3
        chip_id = f"{row_letter}{pcb_col}"
        
        # Create a visually defined Label representing the socket/IC
        socket_label = tk.Label(
            grid_frame, 
            text=chip_id, 
            font=("Consolas", 10, "bold"), 
            width=6, 
            height=2, 
            relief="groove", 
            borderwidth=2,
            bg=COLOR_DEFAULT_BG,
            fg=COLOR_DEFAULT_FG
        )
        # Position in grid (offset by header rows and row label column)
        socket_label.grid(row=row_idx_in_grid+2, column=bit_idx+1, padx=4, pady=8)
        
        # Store reference in global dictionary for highlighting later
        visual_chip_widgets[chip_id] = socket_label
        
    # Optional Bank Description at the end of the row
    ttk.Label(grid_frame, text=bank_desc, font=("Segoe UI", 8, "italic"), foreground="gray", justify="left").grid(row=row_idx_in_grid+2, column=9, padx=(15,0), sticky="w")

# --- Legend ---
legend_frame = ttk.Frame(tab4, padding="20")
legend_frame.pack(side="bottom", fill="x")

ttk.Label(legend_frame, text="Legend:", font=("Segoe UI", 9, "bold")).pack(anchor="w")
f_lbl = tk.Label(legend_frame, text=" [ XX ] ", font=("Consolas", 9, "bold"), bg=COLOR_FAULT_BG, fg=COLOR_FAULT_FG, relief="sunken", borderwidth=2)
f_lbl.pack(side="left", padx=(10, 5), pady=5)
ttk.Label(legend_frame, text="= Faulty Chip Location", font=("Segoe UI", 9)).pack(side="left", pady=5)

root.mainloop()